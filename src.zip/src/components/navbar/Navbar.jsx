import React from 'react'
import "./Navbar.css"
import { NavLink } from 'react-router-dom'
import { BsSearch, BsGlobe } from 'react-icons/bs'
import { GoPerson } from 'react-icons/go'

const Navbar = () => {
  return (
    <div className='navbar'>
      <div className="logo"></div>
      <NavLink exact to="/">
        <div className="scn_logo"></div>
      </NavLink>
      <p className='mode'>Modes</p>
      <ul className="collection">
        <li className="item">
          <NavLink to="/product" >Battle Pass</NavLink>
        </li>
        <li className="item">Crew</li>
        <li className="item">V-Bucks</li>
        <li className="item">Competitive</li>
        <li className="item">News</li>
        <li className="item">Merch</li>
        <li className="item">Cosplay</li>
        <li className="item">Help</li>
      </ul>
      <BsSearch />
      <BsGlobe />
      <button className='signin'> <GoPerson /> Sign In</button>
      <button className='dowload'>Dowload</button>
    </div>
  )
}

export default Navbar