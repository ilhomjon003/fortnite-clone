import React from 'react'
import Banner from '../../components/banner/Banner'
// import Banner from '../../components/banner/Banner'
// import Parent from '../../learning-context-api/Parent'
// import { useStateValue } from "../../context/reducer"
const Home = () => {
  // const [state, action ] = useStateValue()
  return (
    <div className='home'>
      <Banner />
    </div>
  )
}

export default Home



    //  {/* <Parent /> */}
    //  <h2>{state.count}</h2>